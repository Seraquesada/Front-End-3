import React from 'react'
import { Container } from "./dashboard.styles.js";
import Navbar from "../Navbar/Navbar.jsx";
import Board from "../Board/Board.jsx";

const Dashboard = () => {
    return (
        <Container>
            <Navbar />
            <Board />
        </Container>
    )
}

export default Dashboard