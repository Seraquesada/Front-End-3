
import Dashboard from "./components/Dashboard/Dashboard";
function App() {
  return <Dashboard />
}

export default App
