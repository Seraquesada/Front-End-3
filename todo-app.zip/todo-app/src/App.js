import { Fragment } from 'react';
import Dashboard from './components/Dashboard/Dashboard';

function App() {
  return (
    <Fragment>
      <Dashboard/>
    </Fragment>
  );
}

export default App;
