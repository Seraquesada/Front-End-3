import React from 'react';
import { UL } from "./tasks.style";
import { AiOutlineCheck, AiFillDelete, AiOutlineStar } from "react-icons/ai";
import styles from "./tasks.module.css";

const TasksList = () => {
  return (
    <UL>
        <Task
            task={"Comprar leche"}
            id={1}
        />
        <Task
            task={"Ir al supermercado"}
            id={2}
        />
        <Task
            task={"Caminar al perro"}
            id={3}
        />
        <Task
            task={"Purificar el agua"}
            id={4}
        />
        <Task
            task={"Escribir cartas"}
            id={5}
        />
    </UL>
  )
};

const Task = ({ task, id }) => {
    return (
        <li style={taskCompStyle}>
            <p>{task}</p>
            <div style={iconStyle}>
                <AiOutlineStar 
                    onClick={() => alert(`La tarea ${id} ha sido hecha Importante`)}
                    size={20}
                    className={styles['singleIcon']}
                />
                <AiOutlineCheck
                    onClick={() => alert(`La tarea ${id} ha sido chuleada.`)} 
                    size={20}
                    className={styles['singleIcon']}
                />
                <AiFillDelete 
                    onClick={() => alert(`La tarea ${id} ha sido eliminada.`)}
                    size={20}
                    className={styles['singleIcon']}
                />
            </div>
        </li>
    )
};

const taskCompStyle = { display: "flex", textAlign: "center", alignItems: "center", justifyContent: "space-between"};
const iconStyle = { display: "flex", gap: "5px"};

export default TasksList;