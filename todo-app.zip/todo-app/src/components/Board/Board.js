import React from 'react';
import {BoardContainer} from "./board.style";
import Todo from './todos/Todo';
import SearchEngine from './searchEngine/searchEngine';
import TasksList from './TasksList/TasksList';

const Board = () => {
  return (
    <BoardContainer>
      <div style={div15}>
        <Todo/>
      </div>
      <div style={div85}>
        <SearchEngine/>
        <TasksList/>
      </div>
    </BoardContainer>
  )
}

const div15 = { 
  width: "230px", 
  height: "100vh", 
  borderRight: "1px solid #C7CBC4",
  padding: "20px",
}

const div85 = { 
  width: "85%", 
  height: "100vh", 
  borderLeft: "1px solid #C7CBC4",
  padding: "0px 20px",
}

export default Board;

