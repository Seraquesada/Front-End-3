import React from 'react'
import { Container } from "./dashboard.styles";
import Navbar from '../Navbar/Navbar';
import Board from '../Board/Board';

const Dashboard = () => {
  return (
    <Container>
        <Navbar />
        <Board />
    </Container>
  )
}

export default Dashboard