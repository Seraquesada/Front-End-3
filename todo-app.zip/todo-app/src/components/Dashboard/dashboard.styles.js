import styled from "styled-components";

export const Container = styled.div`
    height: 100vh;
    min-height: 100%;
    padding: 20px;
    background-color: gray;
`;